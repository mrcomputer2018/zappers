import React from "react";

const ZappersList = (props) => {
    return (
        <div>
            Zappers List
        </div>
    )
}
export default ZappersList;