import React from "react";
import ZappersList from "../components/ZappersList";

const Home = (props) => {
    return (
        <div>
            Home
            <ZappersList></ZappersList>
        </div>
    )
}
export default Home;
